export interface CategoryInterface {
  id: number
  nameuk: string
  nameru: string
  svg: string
}
export interface CategoryTitleInterface {
  id: number
  nameuk: string
  nameru: string
  categoryId: number
}
