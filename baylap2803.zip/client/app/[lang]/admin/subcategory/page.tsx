import AddSubcategory from '@/app/components/Admin/Subcategory/AddSubcategory'
import React from 'react'

const page = () => {
  return (
    <div>
      <AddSubcategory />
    </div>
  )
}

export default page
